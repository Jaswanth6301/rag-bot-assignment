import os
import pickle
import faiss
import numpy as np
import streamlit as st
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

INDEX_DIR = "index"
TOP_K = 3

# -----------------------------
# MODELS
# -----------------------------

embedding_model = SentenceTransformer("all-MiniLM-L6-v2")

chat_model = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key="YOUR_GEMINI-API_KEY"
)

# -----------------------------
# LOAD INDEX
# -----------------------------

@st.cache_resource
def load_index():
    index = faiss.read_index(f"{INDEX_DIR}/faiss.index")

    with open(f"{INDEX_DIR}/chunks.pkl", "rb") as f:
        chunks = pickle.load(f)

    return index, chunks

# -----------------------------
# RETRIEVAL
# -----------------------------

def retrieve_context(query, k=TOP_K):
    index, chunks = load_index()

    query_embedding = embedding_model.encode([query])
    query_embedding = np.array(query_embedding).astype("float32")

    scores, indices = index.search(query_embedding, k)

    retrieved_chunks = []
    seen = set()

    for i in indices[0]:
        chunk = chunks[i]
        key = f"{chunk['source']}_{chunk['page']}"

        if key not in seen:
            retrieved_chunks.append(chunk)
            seen.add(key)

    context = "\n\n".join([chunk["text"] for chunk in retrieved_chunks])

    return context, retrieved_chunks

# -----------------------------
# CHAT FUNCTION
# -----------------------------

def docu_chat(user_query):
    context, source_docs = retrieve_context(user_query)

    if not context.strip():
        return {
            "answer": "No relevant information found in documents.",
            "source_documents": []
        }

    prompt = f"""
You are a helpful document question-answering assistant.

Answer ONLY using the provided context.

If answer is not available in context, say:
'I could not find this information in the uploaded documents.'

Context:
{context}

Question:
{user_query}
"""

    response = chat_model.invoke(prompt)

    return {
        "answer": response.content,
        "source_documents": source_docs
    }

# -----------------------------
# STREAMLIT UI
# -----------------------------

def main():
    st.set_page_config(
        page_title="Document Q&A Bot",
        page_icon="📄",
        layout="wide"
    )

    st.title("📄 RAG Document Q&A Bot")
    st.markdown("Ask questions from your uploaded documents")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    user_query = st.chat_input("Ask your question...")

    if user_query:
        result = docu_chat(user_query)

        st.session_state.chat_history.append({
            "question": user_query,
            "answer": result["answer"],
            "sources": result["source_documents"]
        })

    for chat in reversed(st.session_state.chat_history):
        with st.chat_message("user"):
            st.write(chat["question"])

        with st.chat_message("assistant"):
            st.write(chat["answer"])

            if chat["sources"]:
                with st.expander("View Sources"):
                    for doc in chat["sources"]:
                        st.markdown(
                            f"**{doc['source']}** (Page {doc['page']})"
                        )
                        st.write(doc["text"][:300] + "...")
                        st.divider()

if __name__ == "__main__":
    main()