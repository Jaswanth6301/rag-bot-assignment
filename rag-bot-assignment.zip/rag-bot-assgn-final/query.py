import os
import pickle
import faiss
import numpy as np
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

INDEX_DIR = "index"
TOP_K = 3

embedding_model = SentenceTransformer("all-MiniLM-L6-v2")

chat_model = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key="YOUR_GEMINI-API_KEY"
)


def load_index():
    index = faiss.read_index(f"{INDEX_DIR}/faiss.index")
    with open(f"{INDEX_DIR}/chunks.pkl", "rb") as f:
        chunks = pickle.load(f)
    return index, chunks


def retrieve_context(query, k=3):
    index, chunks = load_index()

    query_embedding = embedding_model.encode([query])
    faiss.normalize_L2(query_embedding)

    scores, indices = index.search(query_embedding.astype(np.float32), k)

    retrieved_chunks = [chunks[i] for i in indices[0]]
    context = "\n\n".join([chunk["text"] for chunk in retrieved_chunks])

    return context, retrieved_chunks


def docu_chat(user_query):
    context, source_docs = retrieve_context(user_query)

    if not context.strip():
        return {
            "answer": "No relevant information found in documents.",
            "source_documents": []
        }

    prompt = f"""
You are a helpful document QA assistant.

Answer ONLY using the provided context.
If answer is not present, say:
'I could not find this in the uploaded documents.'

Context:
{context}

Question:
{user_query}
"""

    response = chat_model.invoke(prompt)

    return {
        "answer": response.content,
        "source_documents": source_docs
    }


def main():
    print("=" * 50)
    print("DOCUMENT Q&A BOT")
    print("=" * 50)

    while True:
        q = input("\nAsk Question (or type exit): ")

        if q.lower() == "exit":
            break

        result = docu_chat(q)

        print("\nAnswer:")
        print(result["answer"])

        print("\nSources:")
        for doc in result["source_documents"]:
            print(f"- {doc['source']} (Page {doc['page']})")


if __name__ == "__main__":
    main()