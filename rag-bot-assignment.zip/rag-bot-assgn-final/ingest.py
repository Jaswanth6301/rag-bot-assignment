import os
import pickle
import hashlib
from pathlib import Path

import fitz
import faiss
import docx
import numpy as np

from tqdm import tqdm
from sentence_transformers import SentenceTransformer

# -----------------------------
# CONFIG
# -----------------------------

DATA_DIR = Path("data")
INDEX_DIR = Path("index")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100

EMBED_MODEL = "all-MiniLM-L6-v2"

# -----------------------------
# EMBEDDING MODEL
# -----------------------------

embedder = SentenceTransformer(EMBED_MODEL)

# -----------------------------
# DOCUMENT LOADERS
# -----------------------------

def load_pdf(path):
    pages = []

    doc = fitz.open(path)

    for page_num, page in enumerate(doc, start=1):
        text = page.get_text()

        if len(text.strip()) > 50:
            pages.append({
                "text": text,
                "source": path.name,
                "page": page_num
            })

    return pages


def load_txt(path):
    text = path.read_text(encoding="utf-8")

    return [{
        "text": text,
        "source": path.name,
        "page": 1
    }]


def load_docx(path):
    document = docx.Document(path)

    paragraphs = [p.text for p in document.paragraphs if p.text.strip()]

    text = "\n".join(paragraphs)

    return [{
        "text": text,
        "source": path.name,
        "page": 1
    }]

# -----------------------------
# LOAD ALL FILES
# -----------------------------

def load_documents():

    supported = {
        ".pdf": load_pdf,
        ".txt": load_txt,
        ".docx": load_docx
    }

    all_pages = []

    for file in DATA_DIR.iterdir():

        ext = file.suffix.lower()

        if ext in supported:

            print(f"Loading {file.name}")

            loader = supported[ext]

            pages = loader(file)

            all_pages.extend(pages)

    return all_pages

# -----------------------------
# CHUNKING
# -----------------------------

def chunk_text(text):

    chunks = []

    start = 0

    while start < len(text):

        end = start + CHUNK_SIZE

        chunk = text[start:end]

        chunks.append(chunk)

        start = end - CHUNK_OVERLAP

    return chunks

# -----------------------------
# BUILD CHUNKS
# -----------------------------

def build_chunks(pages):

    all_chunks = []

    for page in pages:

        chunks = chunk_text(page["text"])

        for idx, chunk in enumerate(chunks):

            chunk_id = hashlib.md5(
                chunk.encode()
            ).hexdigest()[:12]

            all_chunks.append({
                "id": chunk_id,
                "text": chunk,
                "source": page["source"],
                "page": page["page"]
            })

    return all_chunks

# -----------------------------
# EMBEDDINGS
# -----------------------------

def create_embeddings(chunks):

    texts = [c["text"] for c in chunks]

    embeddings = embedder.encode(
        texts,
        batch_size=32,
        show_progress_bar=True
    )

    return np.array(embeddings).astype("float32")

# -----------------------------
# SAVE INDEX
# -----------------------------

def save_index(index, chunks):

    INDEX_DIR.mkdir(exist_ok=True)

    faiss.write_index(
        index,
        str(INDEX_DIR / "faiss.index")
    )

    with open(INDEX_DIR / "chunks.pkl", "wb") as f:
        pickle.dump(chunks, f)

# -----------------------------
# MAIN
# -----------------------------

def main():

    print("=" * 50)
    print("RAG INDEXING STARTED")
    print("=" * 50)

    pages = load_documents()

    print(f"\nLoaded Pages: {len(pages)}")

    chunks = build_chunks(pages)

    print(f"Total Chunks: {len(chunks)}")

    embeddings = create_embeddings(chunks)

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatL2(dimension)

    index.add(embeddings)

    save_index(index, chunks)

    print("\nINDEX CREATED SUCCESSFULLY")


if __name__ == "__main__":
    main()