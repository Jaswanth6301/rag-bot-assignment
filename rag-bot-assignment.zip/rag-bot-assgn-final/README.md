# RAG Document Q&A Bot

A Retrieval-Augmented Generation (RAG) pipeline that lets you ask natural language questions about a collection of documents and get grounded, cited answers — powered by Google Gemini.

---

## What It Does

This bot ingests a set of documents (PDF, TXT, or DOCX), splits them into chunks, embeds them using Google's `text-embedding-004` model, stores the vectors in a persistent FAISS index, and at query time retrieves the most relevant chunks and feeds them as context to `gemini-1.5-flash` to generate accurate, cited answers. It never makes up information — if the answer isn't in the documents, it says so.

---

## Tech Stack

| Library / Tool | Version | Purpose |
|---|---|---|
| Python | 3.11+ | Runtime |
| google-generativeai | 0.7.2 | Gemini embeddings + generation |
| faiss-cpu | 1.8.0 | Vector similarity search |
| PyMuPDF | 1.24.5 | PDF text extraction |
| python-docx | 1.1.2 | DOCX text extraction |
| numpy | 1.26.4 | Numerical arrays for embeddings |
| python-dotenv | 1.0.1 | `.env` file loading |
| tqdm | 4.66.4 | Progress bars during indexing |
| streamlit | 1.36.0 | Optional web UI |

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     INDEXING STEP (ingest.py)               │
│                                                             │
│  /data folder                                               │
│  (PDF, TXT, DOCX)                                           │
│       │                                                     │
│       ▼                                                     │
│  Document Loader  ──→  Text Chunker  ──→  Gemini Embedder  │
│  (PyMuPDF,              (fixed-size,       (text-embedding- │
│   python-docx,           600 chars,         004, batched)   │
│   plain text)            100 overlap)                       │
│                               │                             │
│                               ▼                             │
│                        FAISS Index  ──→  Saved to /index/   │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                   QUERYING STEP (query.py)                  │
│                                                             │
│  User Question                                              │
│       │                                                     │
│       ▼                                                     │
│  Gemini Embedder  ──→  FAISS Search  ──→  Top-5 Chunks     │
│  (query embedding)     (cosine sim)        + metadata       │
│                               │                             │
│                               ▼                             │
│                    Prompt Builder  ──→  gemini-1.5-flash    │
│                    (chunks as context)   (answer + citations)│
│                               │                             │
│                               ▼                             │
│                    Answer printed to terminal               │
└─────────────────────────────────────────────────────────────┘
```

---

## Chunking Strategy

**Strategy: Fixed-size character chunking with overlap**

- **Chunk size:** 600 characters
- **Overlap:** 100 characters
- **Why this strategy:** Fixed-size chunking is predictable, easy to reason about, and works uniformly across all document types (PDFs, DOCX, TXT) regardless of how the source document is structured. An overlap of 100 characters ensures that context is not lost when the boundary of a chunk falls in the middle of a sentence or idea. This approach avoids the brittleness of sentence-based splitting, which depends heavily on punctuation quality in the extracted text.

---

## Embedding Model and Vector Database

**Embedding Model: `models/text-embedding-004` (Google Gemini)**
- 768-dimensional dense vectors
- Free tier available via Google AI Studio
- Separate task types for documents (`retrieval_document`) and queries (`retrieval_query`) optimize retrieval performance

**Vector Database: FAISS (Facebook AI Similarity Search)**
- In-process, no server required
- `IndexFlatIP` (inner product) with L2-normalised vectors = cosine similarity
- Persists to disk as `index/faiss.index` + `index/chunks.pkl`
- Separation between indexing step (`ingest.py`) and querying step (`query.py`) is explicit and clean

---

## Project Structure

```
rag_qa_bot/
├── ingest.py          # Step 1: Load, chunk, embed, index documents
├── query.py           # Step 2: Interactive CLI Q&A bot
├── app.py             # (Bonus) Streamlit web UI
├── requirements.txt   # Python dependencies
├── .env.example       # Template for API key
├── .gitignore         # Keeps secrets and index off GitHub
├── README.md          # This file
└── data/              # Your documents go here
    ├── internet_history.txt
    ├── machine_learning_intro.txt
    ├── climate_change.txt
    ├── space_exploration.txt
    └── blockchain_crypto.txt
```

---

## Setup Instructions

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/rag-qa-bot.git
cd rag-qa-bot
```

### 2. Create and activate a virtual environment

```bash
python -m venv venv

# On Windows:
venv\Scripts\activate

# On Mac/Linux:
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up your Gemini API key

Get a free API key at: https://aistudio.google.com/app/apikey

```bash
cp .env.example .env
```

Then open `.env` and replace the placeholder with your actual key:

```
GEMINI_API_KEY=your_actual_key_here
```

### 5. Add your documents

Place PDF, TXT, or DOCX files in the `data/` folder.
The repo already includes 5 sample `.txt` documents on diverse topics.
You can replace them or add your own.

### 6. Run the indexing step

```bash
python ingest.py
```

This loads all documents from `data/`, chunks them, embeds them with Gemini, and saves the FAISS index to `index/`. You only need to run this once (or again if you add new documents).

Expected output:
```
=====================================================
  RAG Ingestion Pipeline — Starting
=====================================================

[1/4] Loading documents from ./data …
  Loading: blockchain_crypto.txt
    → 1 page(s) extracted
  ...
  Total pages/sections loaded: 5

[2/4] Chunking text …
  Total chunks created: 98

[3/4] Embedding chunks with Gemini …
  Embedded 98 chunks, shape: (98, 768)

[4/4] Building FAISS index and saving to disk …
  Index saved to 'index/'

✅  Ingestion complete!
    Now run:  python query.py
```

### 7. Run the Q&A bot

```bash
python query.py
```

Type questions at the prompt. Type `quit` to exit.

### 8. (Optional) Run the Streamlit web UI

```bash
streamlit run app.py
```

This opens a browser-based chat interface at `http://localhost:8501`.

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `GEMINI_API_KEY` | Yes | Your Google Gemini API key from AI Studio |

**Never commit your `.env` file or any API key to GitHub.** The `.gitignore` already excludes `.env`.

---

## Example Queries

| Question | Expected Answer Theme |
|---|---|
| "Who invented the World Wide Web and when?" | Tim Berners-Lee, 1989, at CERN |
| "What is the difference between supervised and unsupervised learning?" | Labeled vs unlabeled data; classification/regression vs clustering |
| "What causes the greenhouse effect?" | CO2, methane, nitrous oxide trapping solar heat |
| "Who was the first human to walk on the Moon?" | Neil Armstrong, Apollo 11, July 20 1969 |
| "What is a smart contract in blockchain?" | Self-executing code on Ethereum enforcing agreement terms |
| "What is the current price of Bitcoin?" | Not in documents — bot should say it cannot find the answer |

---

## Known Limitations

- **No re-ranking:** The bot retrieves top-5 chunks by cosine similarity. A cross-encoder re-ranker could improve relevance for complex questions.
- **Fixed chunk size:** 600-character fixed chunks may split mid-sentence. A sentence-aware or semantic chunker would reduce this issue.
- **No memory:** Each question is answered independently. The bot has no conversation memory — follow-up questions may lose prior context.
- **Rate limits:** The free Gemini API tier has per-minute rate limits. Large document sets may require a pause or paid tier.
- **OCR not supported:** Scanned PDFs (images of text) will return empty or garbled text. Only machine-readable PDFs are supported.
- **English only:** Not tested on non-English documents; embedding quality may vary.
